package com.my.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login.do") // 2.5버전에서도 사용가능한 기능!
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginServlet() {
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=utf-8");
		PrintWriter out = response.getWriter();
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		if(id==null||pw==null||id.length()==0||pw.length()==0) {
			//필요없다..html에서 조건 걸어줬기때문...여기서 sendRedirect쓰는것임
			response.sendRedirect("./login.jsp");
			return;
		}
		
		boolean flag = true;//로그인성공여부
		
		if (id.equals("scott")&&pw.equals("tiger")) {
			//로그인이 성공 했을 시 세션 만들기
			HttpSession session = request.getSession(); //세션 객체 생성
			session.setAttribute("login", id); //로그인 정보 박기
			String view = "main.jsp";
			request.getRequestDispatcher(view).forward(request, response);
			return; //흐름은 main.jsp로 넘겨줬으니 종료
		} else {
			request.setAttribute("errorMsg", "아이디와 패스워드가 일치하지 않습니다.");
			//out.println("<h1>로그인 실패</h1><br><a href='./login.html'>로그인페이지로</a>");
			request.getRequestDispatcher("login.jsp").forward(request, response);
			return;
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
