package com.my.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CalcController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String number = request.getParameter("number");
		if(number=="null"||number.isEmpty()) {
			request.setAttribute("errorMsg", "값 입력해주세요");
			//response.sendRedirect("input.jsp"); //데이터 안들어왔으니 다시 입력창으로 보내는 것.BUT 이전의 요청객체 깨짐
			//요청객체를 꼭 살려야 한다면 포워딩을 시켜줘야한다. 저 에러메세지를 찍으려면 요청객체가 죽으면 안되니까 꼭 살려야함!!!
			request.getRequestDispatcher("input.jsp").forward(request, response); //input.jsp로 흐름 변환
			return;//더이상 수행하지 않도록 리턴시켜버림
		}
		int num = Integer.parseInt(number);
		String view = "calcview.jsp";
		ArrayList<String> list = new ArrayList<String>();
		for(int i = 1; i<10; i++ ) {
			list.add(num+" x "+i+" = "+(num*i));
		}
		request.setAttribute("data", list); //request에 담아줘야 처리페이지에서 데이터를 쓸 수 있다.
		request.getRequestDispatcher(view).forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
