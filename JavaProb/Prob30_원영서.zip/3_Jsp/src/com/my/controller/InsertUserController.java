package com.my.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.my.model.UserInfo;

//out객체 만들 필요없다. 이제 UI핸들링은 JSP에게 넘겨줄 것이기 때문!
public class InsertUserController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public InsertUserController() {
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("utf-8");// 데이터 넘어올때 한글 깨지지 않도록
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String name = request.getParameter("name");
		String role = request.getParameter("role");
		UserInfo model = new UserInfo(id, pw, name, role); // VO에 데이터를 담아서 DB로 넘겨주기 위함
		// Service만 있다면 충분히 DB에 insert가능 .아직은 그냥 insert했다고 치고 forwarding
		System.out.println("DB add : " + model);
		request.setAttribute("data", model); // JSP에 데이터를 사용할 수 있게 vo값을 넣어주는데 그때 키값을 data로 설정
		String view = "result.jsp";
		// 흐름을 바꾸는게 RequestDispatcher
		RequestDispatcher rd = request.getRequestDispatcher(view);
		rd.forward(request, response);// 이게 바로 흐름을 제어하는 방법 -> 즉 서블릿은 컨트롤러 역할을 하는 것.
		// requset.getRequsetDispatcher(view).forward(request, response); //위의 두줄을 한줄로
		// 표현하면 이렇게
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
